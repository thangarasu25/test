import { Component, OnInit } from '@angular/core';
import { PortfolioService } from '../services/portfolio.service';
import { Investment } from '../inverserment/investment.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styles: [
    `
    h1 { font-weight: normal; }
  
    .dashboard {
      max-width: 800px;
      margin: 0 auto;
      padding: 1rem;
    }
  
    .dashboard table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 1rem;
    }
  
    .dashboard th,
    .dashboard td {
      padding: 0.5rem;
      border: 1px solid #ccc;
      text-align: left;
    }
  
    .dashboard th {
      background-color: #f0f0f0;
    }
    `,
  ],
})
export class DashboardComponent implements OnInit {
  investments: Investment[] = [];

  constructor(private portfolioService: PortfolioService) {}

  ngOnInit(): void {
    this.portfolioService.investments$.subscribe((data) => {
      this.investments = data;
    });
  }
}
