import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { DashboardComponent } from '../../dashboard/dashboard.component';
import { InvestmentFormComponent } from '../../investment-form/investment-form.component';
import { ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'investment', component: InvestmentFormComponent },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }, // default route
];

@NgModule({
  declarations: [AppComponent, DashboardComponent, InvestmentFormComponent],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes), // IMPORTANT
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
