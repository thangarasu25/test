import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Investment } from '../inverserment/investment.model';

@Injectable({ providedIn: 'root' })
export class PortfolioService {
  private investmentsSubject = new BehaviorSubject<Investment[]>([]);
  investments$ = this.investmentsSubject.asObservable();

  addInvestment(investment: Investment) {
    const current = this.investmentsSubject.getValue();
    this.investmentsSubject.next([...current, investment]);
  }
}
