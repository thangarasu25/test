export interface Investment {
  id: number;
  assetType: string;
  quantity: number;
  purchasePrice: number;
  purchaseDate: Date;
}
