import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvestmentFormComponent } from './investment-form.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [InvestmentFormComponent],
  imports: [CommonModule, ReactiveFormsModule],
  exports: [InvestmentFormComponent],
})
export class InvestmentModule {}
