import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PortfolioService } from '../services/portfolio.service';
import { Investment } from '../inverserment/investment.model';

@Component({
  selector: 'app-investment-form',
  templateUrl: './investment-form.component.html',
  styleUrls: ['./investment-form.component.scss'],
})
export class InvestmentFormComponent {
  investmentForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private portfolioService: PortfolioService
  ) {
    this.investmentForm = this.fb.group({
      assetType: ['', Validators.required],
      quantity: [0, [Validators.required, Validators.min(1)]],
      purchasePrice: [0, [Validators.required, Validators.min(0.01)]],
      purchaseDate: ['', Validators.required],
    });
  }

  onSubmit() {
    if (this.investmentForm.valid) {
      this.portfolioService.addInvestment(
        this.investmentForm.value as Investment
      );
      this.investmentForm.reset();
    }
  }
}
